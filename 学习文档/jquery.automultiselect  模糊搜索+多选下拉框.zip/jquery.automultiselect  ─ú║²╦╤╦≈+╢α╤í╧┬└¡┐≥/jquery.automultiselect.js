;(function($){
//	$.autoselect = function(select, options){
//		this.init(select, options);
//	};
	$.extend({
		autoselect:function(select, options){
			this.init(select, options);
		}
	})
	
	$.extend($.autoselect.prototype, {
		setting:{
			inputIdTransform:    function(id)   { return id + "_flexselect"; },
		    //inputNameTransform:  function(name) { return; },
		    dropdownIdTransform: function(id)   { return id + "_flexselect_dropdown"; }
		},
		select: null,
    	input: null,
    	dropdown: null,
    	dropdownList: null,
    	cache:{},
		init : function (select, options){
			this.settings = $.extend({}, this.settings, options);
	        this.select = $(select);
	        this.preloadCache();
	        this.renderControls();
	        this.wire();
		},
		preloadCache: function() {
	      var name, value;
//	      var indexGroup = this.settings.indexOptgroupLabels;
	      this.cache = this.select.find("option").map(function() {
	        name = $(this).text();
	        value = $(this).val();
//	        group = $(this).parent("optgroup").attr("label");
//	        text = indexGroup ? [name, group].join(" ") : name;
//	        disabled = $(this).parent("optgroup").attr("disabled") || $(this).attr('disabled');
	        return { name: $.trim(name), value: $.trim(value)};
	      });
	    },
	    renderControls: function() {
	      var self = this;
//	      var selected = this.settings.preSelection ? this.select.find("option:selected") : null;
		  $("#"+this.setting.inputIdTransform(this.select.attr("id"))).remove();
	      $("#"+this.setting.dropdownIdTransform(this.select.attr("id"))).remove();
	      this.input = $("<input type='text' autocomplete='off' maxlength='20'>").attr({
	        id: this.setting.inputIdTransform(this.select.attr("id")),
	        name: this.select.attr("name")//this.settings.inputNameTransform(),
//	        accesskey: this.select.attr("accesskey"),
//	        tabindex: this.select.attr("tabindex"),
//	        style: this.select.attr("style")
//	        placeholder: this.select.attr("data-placeholder")
	      }).addClass(this.select.attr("class"))
//	      .val($.trim(selected ? selected.text():  ''))
//	      .css({
//	        visibility: 'visible'
//	      })
	      ;
	      this.dropdown = $("<div id="+this.setting.dropdownIdTransform(this.select.attr("id"))+" class='selec'>" +
	      					"<div class='brand_bg' style='display: block;'>"+
						    "<div class='brand_name_bg'>"+
						      "<div class='brand_name' id='master-index_list'>"+
						        "<div class='se_all'>"+
						        "<a href='javascript:void(0);' class='all_l'>ȫѡ</a>"+
						        "<a href='javascript:void(0);' class='all_r'>ȫ��ѡ</a>"+
						        "</div>"+
						      "</div>"+
						    "</div>"+
						    "</div>"+
						    "</div>");
	      this.dropdownList = $("<dl id='master-indexletters_A'></dl>");
	      $(this.cache).each(function(i, obj){
	      		self.dropdownList.append("<dd><a href='javascript:void(0);'> <input id='c"+i+"' name='' class='cs' type='checkbox' value='"+obj.value+"' /><label for='c"+i+"' class='val'>"+obj.name+"</label></a></dd>")
	      })
//	      this.dropdownList = $("<dd><a href='javascript:;'> <input name='' type='checkbox' value='' /> AC Schnitzer</a></dd>");
	      this.dropdown.find(".brand_name").append(this.dropdownList);
//	      .hide();
	       this.select.after(this.dropdown);
	       this.select.after(this.input);
	       this.select.hide();
//	      $("body").append(this.dropdown);
	    },
	    wire: function() {
	      var self = this;
	
	      this.input.click(function() {
	        self.dropdown.show();
	      });
	
	      this.input.mouseup(function(event) {
	        event.preventDefault();
	      });
	
	      this.input.focus(function() {
	        self.dropdown.show();
	      });
	
	      this.input.blur(function() {
//	      	self.dropdown.hide();
	      });
	
	      this.dropdown.mouseover(function(event) {
	        //self.dropdownMouseover = true;
	      });
	      this.dropdown.mouseleave(function(event) {
//	        self.dropdownMouseover = false;
	      	self.dropdown.hide();
	      });
	      this.dropdown.mousedown(function(event) {
	        event.preventDefault();
	      });
	
	      this.input.keyup(function(event) {
	        switch (event.keyCode) {
	          case 13: // return
	            event.preventDefault();
	            break;
	          case 27: // esc
	            event.preventDefault();
	            break;
	          default:
	          	var val = $(this).val().toUpperCase();;
	          	self.dropdownList.find(".val").each(function(i, obj){
	          		var temp = ($(obj).html()).replace(/[ ]/g,'').toUpperCase();
	          		if(temp.indexOf(val) < 0){
	          			$(obj).parents("dd").hide();
	          			$(obj).parents("dd").find(":checkbox").prop("checked",false);
	          		}else{
	          			$(obj).parents("dd").show();
	          		}
	          	})
	            break;
	        }
	      });
	      this.dropdown.find(".all_l").click(function(){
	      	self.dropdownList.find(":checkbox").prop("checked",false);
//	      	self.dropdownList.find("input[type=checkbox]:visible").attr("checked",true);
	      	self.dropdownList.find(":checkbox:visible").prop("checked",true);//update zjc   jquery ��prop�����������ж��߼�ֵ��
	      	if($.isFunction(self.settings.checked)){
	      		self.settings.checked();
	      	}
	      });
	      this.dropdown.find(".all_r").click(function(){
//	      	self.dropdownList.find("input[type=checkbox]").attr("checked",false);
	      	self.dropdownList.find(":checkbox").prop("checked",false);//update zjc
	      	if($.isFunction(self.settings.checked)){
	      		self.settings.checked();
	      	}
	      });
	      
	      this.dropdown.find(".cs").click(function(){
	      	if($.isFunction(self.settings.checked)){
	      		self.settings.checked();
	      	}
	      });
	    }
    
	});

	$.fn.extend({
		autoselect:function(options){
						this.each(function(){
							if(this.tagName == "SELECT"){
								new $.autoselect(this, options);
							}
						});
					}
	})
//	$.fn.autoselect = function(options){
//		this.each(function(){
//			if(this.tagName == "SELECT"){
//				new $.autoselect(this, options);
//			}
//		});
//	}
})(jQuery)