<template>
  <div class="app">
  <img src="./assets/logo.png">
  {{totalPrice}}
  <apple></apple>
  <banana></banana>
  </div>
</template>

<script>
import Apple from './components/applevuex'
import Banana from './components/bananavuex'
export default {
    components:{
      Apple,Banana
    },
    data(){
      return{

      }
    },
    computed:{
      totalPrice(){
        return this.$store.getters.getTotal
      }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
