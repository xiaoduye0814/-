// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import AppVuex from './AppVuex'
import VueRouter from 'vue-router'

Vue.config.productionTip = false

Vue.use(VueRouter)

let store=new Vuex.Store({
    state:{
        totalPrice:0
    },
    getters:{
      getTotal(state){
        return state.totalPrice
      }
    },
    mutations:{
      increment(state,price){
          state.totalPrice += price
      },
      decrement(state,price){
          state.totalPrice -= price
      }
    },
    actions:{
      increase(context,price){
        context.commit('increment',price)
      }
    }
})
let router=new VueRouter({
})

/* eslint-disable no-new */
new Vue({
  el: '#app',
  directives:{
    color:function(el,binding){
        el.style.color=binding.value
    }
},
  router,
  store,
  components: { AppVuex },
  template: '<AppVuex/>' 
})
