<template>
  <div class="app">
  <img src="./assets/logo.png">
    <transition name="fade">
      <keep-alive>
        <router-view></router-view>
      </keep-alive>
    </transition>
    <router-link :to="{name:'applePage'}">to apple</router-link>
    <router-link :to="{path:'banana',param:{color:'yellow'}}">to banana</router-link>
    <router-link :to="{path:'apple/red'}">to redapple</router-link>
  </div>
</template>

<script>
export default {
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
    .fade-enter-active, .fade-leave-active{
        transition:opacity .5s;
    }
    .fade-enter, .fade-leave-active{
        opacity:0;
    }
</style>
