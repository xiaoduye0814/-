<template>
  <div id="app">
    <button v-on:click="show=!show">
        taggle
    </button>
    <p v-color="'green'">hello world</p>
    <input type="text" v-focus>
  </div>
</template>

<script>
import Vue from 'vue'
import componentA from './components/a'
export default {
  directives:{
      focus:{
          inserted(el,binding){
              el.focus()
          }
      }
},
  components:{
      componentA
      },
  data(){
    return{
        show:true,
        currentView:'component-b'
    }
  },
  computed:{
  },
  watch:{
  },
  methods:{
  }
}
</script>

<style>
</style>
