<template>
  <div class="hello">
    <h1>{{msg}}</h1>
    <button @click="addONe">add One</button>
    <button @click="muliONe">muli One</button>
  </div>
</template>

<script>
export default {
    data(){
        return{
            msg:'I am Apple',
            price:10
        }
    },
    methods:{
        addONe(){
            this.$store.dispatch('increase',this.price)
        },
        muliONe(){
            this.$store.commit('decrement',this.price)
        }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
