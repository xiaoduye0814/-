<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    {{numberToDo}}
    <button @click="emitClickMyEvent">clickme</button>
    <button @click="emitEvent">emitEvent</button>
    <slot name="header">no header</slot>
    <p>----------</p>
    <slot name="pooter">no pooter</slot>
  </div>
</template>

<script>
export default {
  props:{'number-to-do':[String,Number]
  },
  name: 'HelloWorld',
  data () {
    return {
      msg: 'I am Component A'
    }
  },
  methods:{
    emitClickMyEvent(){
      this.$emit('my-event',this.msg,this.numberToDo)
    },
    emitEvent(){
      this.$emit("Second-event",this.msg)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
