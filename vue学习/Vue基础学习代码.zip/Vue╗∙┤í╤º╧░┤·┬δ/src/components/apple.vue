<template>
  <div class="hello">
    <h1>{{msg}}</h1>
    <img src="../assets/1.jpg">
    <button @click="getParam">get Param</button>
    <transition name="fade">
      <keep-alive>
        <router-view></router-view>
      </keep-alive>
    </transition>

    
  </div>
</template>

<script>
export default {
    data(){
        return{
            msg:'I am Apple'
        }
    },
    methods:{
        getParam(){
            console.log(this.$route.params)
        }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style >
        .fade-enter-active, .fade-leave-active{
        transition:opacity .5s;
    }
    .fade-enter, .fade-leave-active{
        opacity:0;
    }
</style>
