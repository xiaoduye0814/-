<template>
  <div class="hello">
    <h1>{{msg}}</h1>
        <img src="../assets/2.jpg">
        
  </div>
</template>

<script>
export default {
    data(){
        return{
            msg:'I am Banana'
        }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
