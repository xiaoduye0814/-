C:\Program Files\Microsoft VS Code\bin;
C:\Users\Administrator\AppData\Roaming\npm