<template>
  <div id="app">
    <button v-on:click="show=!show">
        taggle
    </button>
    <div class="ab">
        <transition
        @before-enter="beforeEnter"
        @enter="enter"
        @leave="leave"
        :css="false">
            <p class="animate-p" v-show="show">i am show</p>
        </transition>
    </div>
  </div>
</template>

<script>
import Vue from 'vue'
import componentA from './components/a'
import componentB from './components/b'
export default {
  components:{
      componentA,componentB
      },
  data(){
    return{
        show:true,
        currentView:'component-b'
    }
  },
  computed:{
  },
  watch:{
  },
  methods:{
     beforeEnter:function(el){
         $(el).css({
             left:'-500px',
             opacity:0
         })
     },
     enter:function(el,done){
         $(el).animate({
             left:'200px',
             opacity:1
         },{
             duration:1500,
             complete:done
         })
     },
     leave:function(el,done){
         $(el).animate({
             left:'500px',
             opacity:0
         },{
             duration:1500,
             complete:done
         })
     }
  }
}
</script>

<style>
    .animate-p{
        position:absolute;
        left:200px;
        top:200px;
    }
</style>
