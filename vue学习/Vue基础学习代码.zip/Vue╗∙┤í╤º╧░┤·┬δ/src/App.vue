<template>
  <div id="app">
    <ul>
      <li v-for="(item,index) in list" :class="{odd:index % 2}">
        {{item.name}} -{{item.price}}--{{index}}
      </li>
    </ul>

    <a v-bind:class="className1" v-bind:title="toBaiduTitle">to baidu1</a>
    <a v-bind:class="className2" v-bind:title="toBaiduTitle">to baidu2</a>
    <a v-bind:class="[classA,classB]" v-bind:title="toBaiduTitle">to baidu3</a>
    <a v-bind:class="[classA,{'red-font':haserror}]" v-bind:title="toBaiduTitle">to baidu4 </a>
    <a v-bind:style="styleCss">to baidu5</a>
    <a v-if="THpartA">partA</a>
    <a v-else>no data</a>
    <button v-on:click="target">target</button>
    <button v-on:click="addItem">addItem</button>
    <input @keydown.13="onKeyDown">
    <input type="text" v-model.number="myValue">{{myValue}}
    <componentA :number-to-do="myValue">
      <p slot="header">header</p>
      <p slot="pooter">pooter</p>
    </componentA>
    
    <componentA @my-event="emitMyEvent"></componentA>
    <input type="checkbox" value="apple" v-model="myBox">
    <input type="checkbox" value="orange" v-model="myBox">
    <input type="checkbox" value="banana" v-model="myBox">
    {{myBox}}
     <input type="radio" value="apple1" v-model="myBox1">
    <input type="radio" value="orange1" v-model="myBox1">
    <input type="radio" value="banana1" v-model="myBox1">
    {{myBox1}}
    <select v-model="selection">
      <option v-for="item in selectOptionS" :value=item.value>{{item.text}}</option>
    </select>
    {{selection}}

    <input type="text" v-model="myValueText1">
    {{myValueWihoutNumber}}
    <input type="text" v-model="myValueText2">
    {{myValueWithoutNum()}}

    <componentA @Second-event="consoleMe"></componentA>
    
  </div>
</template>

<script>
import Vue from 'vue'
import componentA from './components/a'
export default {
  components:{
        componentA:componentA
      },
  data(){
    return{
      myValueText2:'',
      myValueText1:'',
      selection:null,
      selectOptionS:[
        {
          text:'apple',
          value:0
        },
        {
          text:'banabn',
          value:1
        }
      ],
      myBox1:[],
      myBox:[],
      myValue:'',
      list:[
        {name:'apple1',
        price:251},
        {name:'apple2',
        price:252},
        {name:'apple3',
        price:253}
      ],
      className1:{
        'red-font':true,
        'blue-font':true
      },
      className2:[
        'red-font','blue-font'
      ],
      classA:'hello',
      classB:'world',
      haserror:false,
      styleCss:{
        'color':'red',
        'font-size':40
      },
      THpartA:true,
      toBaiduTitle:'hello'
    }
  },
  computed:{
    myValueWihoutNumber(){
      return this.myValueText1.replace(/\d/g,'')
    }
  },
  watch:{
    myValue:function(val,oldVal){
        console.log(val,oldVal)
    },
    list:function(){
      this.tellUser()
    }
  },
  methods:{
    tellUser(){
      alert("has changed")
    },
    myValueWithoutNum(){
      return this.myValueText2.replace(/\d/g,'')
    },
    addItem(){
      Vue.set(this.list,1,{name:'apple3',
        price:253})
    },
    target(){
      this.THpartA=!this.THpartA
    },
    onKeyDown(){
      console.log("on key down")
    },
    emitMyEvent(paramValue){
      console.log("emitMyEvent"+paramValue)
    },
    consoleMe(ms1g){
      console.log("I have get the second emit"+ms1g);
    }
  }
}
</script>

<style>

</style>
