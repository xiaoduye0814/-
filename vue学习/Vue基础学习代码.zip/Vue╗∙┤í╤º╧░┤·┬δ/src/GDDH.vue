<template>
  <div id="app">
    <button v-on:click="show=!show">
        taggle
    </button>
    <div class="ab">
        <transition name="fade">
            <p v-show="show">I am showing</p>
        </transition>
        <transition name="my-fade">
            <p v-show="show">I am my-fade</p>
        </transition>
        <transition name="fade" mode="in-out">
            <div :is="currentView"></div>
        </transition>
        <transition name="fade">
            <p v-if="show">I am showing</p>
            <div v-else>no one</div>
        </transition>
        <transition name="fade">
            <p v-if="show" key="1">I am showing1</p>
            <p v-else key="2"> I am showing2</p>
        </transition>
    </div>
  </div>
</template>

<script>
import Vue from 'vue'
import componentA from './components/a'
import componentB from './components/b'
export default {
  components:{
      componentA,componentB
      },
  data(){
    return{
        show:true,
        currentView:'component-b'
    }
  },
  computed:{
  },
  watch:{
  },
  methods:{
      clickConponent(){
          if(this.currentView==='component-a'){
                this.currentView='component-b'
          }else{
                this.currentView='component-a'
          }
      }
  }
}
</script>

<style>
    .fade-enter-active, .fade-leave-active{
        transition:opacity .5s;
    }
    .fade-enter, .fade-leave-active{
        opacity:0;
    }


    .my-fade-enter-active,.my-fade-leave-active{
        transition:all .5s ease-out;
    }
    .my-fade-enter{
        transform:translateY(-500px);
        opacity:0;
    }
    .my-fade-leave=active{
        transform:translateX(-500px);
        opacity:0;
    }
</style>
